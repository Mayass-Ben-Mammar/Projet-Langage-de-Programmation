function Menu() {
    let nav = document.getElementById("Liens");
    nav.classList.toggle("open");
}